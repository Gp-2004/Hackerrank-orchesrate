"""Deterministic, evidence-driven deletion audit for the participant dataset."""

from __future__ import annotations

import csv
import hashlib
import json
import re
import sqlite3
import sys
import unicodedata
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable


ROOT = Path(__file__).resolve().parents[1]
DATASET = ROOT / "dataset"
OUTPUT = ROOT / "output.csv"

OPERATIONS = {
    "FINDING": {
        "REPORT_REMAINING_RECORD": "PRESENT",
        "REPORT_EXPOSED_PII": "PRESENT",
        "REPORT_ACTIVE_DATA_FLOW": "ACTIVE",
        "REPORT_RESTORE_RISK": "ACTIVE",
    },
    "REMEDIATION": {
        "DISABLE_DATA_FLOW": "DISABLED",
        "BLOCK_RESTORE": "BLOCKED",
        "DELETE_RECORD": "ABSENT",
        "REDACT_RECORD": "REDACTED",
        "ANONYMIZE_RECORD": "ANONYMIZED",
    },
    "VERIFICATION": {
        "VERIFY_RECORD_ABSENT": "ABSENT",
        "VERIFY_RECORD_PRESENT": "PRESENT",
        "VERIFY_RECORD_REDACTED": "REDACTED",
        "VERIFY_RECORD_ANONYMIZED": "ANONYMIZED",
        "VERIFY_DATA_FLOW_DISABLED": "DISABLED",
        "VERIFY_RESTORE_BLOCKED": "BLOCKED",
    },
}
PHASE_ORDER = {"FINDING": 0, "REMEDIATION": 1, "VERIFICATION": 2}
OP_ORDER = {
    name: index
    for phase in OPERATIONS.values()
    for index, name in enumerate(phase)
}

COLLECTION_CATEGORIES = {
    "customer_profiles": "USER_PROFILE",
    "deleted_customer_references": "ACCOUNT_TOMBSTONE",
    "secondary_identifiers": "SECONDARY_IDENTIFIER",
    "customer_search_documents": "SEARCH_INDEX_ENTRY",
    "cache_entries": "CACHE_ENTRY",
    "support_conversations": "SUPPORT_MESSAGE",
    "ticket_attachments": "SUPPORT_ATTACHMENT",
    "customer_analytics_reports": "ANALYTICS_PROFILE",
    "product_telemetry": "PRODUCT_TELEMETRY",
    "customer_export_jobs": "USER_EXPORT",
    "marketing_profiles": "MARKETING_PROFILE",
    "email_delivery_events": "EMAIL_DELIVERY_LOG",
    "security_audit_events": "SECURITY_AUDIT_LOG",
    "legal_hold_records": "LEGAL_HOLD_RECORD",
    "backup_catalog": "BACKUP_ARCHIVE",
    "account_tombstones": "ACCOUNT_TOMBSTONE",
    "connector_configurations": "ACTIVE_DATA_FLOW",
    "search_documents": "SEARCH_INDEX_ENTRY",
    "profile_lookups": "USER_PROFILE",
    "backup_restore_entries": "BACKUP_ARCHIVE",
    "backup_restore": "BACKUP_ARCHIVE",
}
SYSTEMS = {
    "USER_PROFILE": "account_service",
    "SECONDARY_IDENTIFIER": "identity_service",
    "SEARCH_INDEX_ENTRY": "search_service",
    "CACHE_ENTRY": "cache_service",
    "SUPPORT_MESSAGE": "support_platform",
    "SUPPORT_ATTACHMENT": "support_platform",
    "ANALYTICS_PROFILE": "analytics_platform",
    "PRODUCT_TELEMETRY": "analytics_platform",
    "USER_EXPORT": "export_service",
    "MARKETING_PROFILE": "marketing_service",
    "EMAIL_DELIVERY_LOG": "email_delivery_service",
    "SECURITY_AUDIT_LOG": "security_service",
    "LEGAL_HOLD_RECORD": "legal_service",
    "BACKUP_ARCHIVE": "backup_service",
    "ACCOUNT_TOMBSTONE": "identity_service",
    "ACTIVE_DATA_FLOW": "integration_service",
}


@dataclass(frozen=True)
class EvidenceRecord:
    file_id: str
    captured_at: str
    observed_at: str
    system_id: str
    category: str
    resource_id: str
    fields: dict[str, Any]
    text: str
    state_hint: str = ""


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def parse_time(value: str) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        if re.match(r"^20\d{2}:\d{2}-\d{2}T", value):
            return datetime.fromisoformat(value[:4] + "-" + value[5:])
        return None


def at_or_before(value: str, cutoff: str) -> bool:
    timestamp = parse_time(value)
    limit = parse_time(cutoff)
    return timestamp is not None and limit is not None and timestamp <= limit


def normalized(value: str) -> str:
    decomposed = unicodedata.normalize("NFKD", value.casefold())
    return "".join(char for char in decomposed if not unicodedata.combining(char))


def canonical_system(value: Any, category: str) -> str:
    if category in SYSTEMS:
        return SYSTEMS[category]
    if value:
        text = str(value).strip()
        if text.startswith(("customer_profiles_", "search_documents_", "customer_search_")):
            return SYSTEMS.get(category, text)
        if text.endswith("_primary") or text.endswith("_read_replica"):
            text = text.rsplit("_", 1)[0]
        if text.endswith("_failover_replica") or text.endswith("_reporting_replica"):
            text = text.rsplit("_", 2)[0]
        if text.endswith("_regional_replicas"):
            text = text.removesuffix("_regional_replicas")
        if text in {"account", "identity", "search", "analytics", "support", "backup"}:
            text += "_service" if text not in {"analytics", "support"} else "_platform"
        return text
    return SYSTEMS.get(category, "unknown_system")


def category_from(value: Any, collection: Any = "") -> str:
    name = str(value or collection or "").casefold()
    if name.upper() in {*SYSTEMS, "DATA_FLOW"}:
        if name.upper() == "DATA_FLOW":
            return "ACTIVE_DATA_FLOW"
        return name.upper()
    for collection_name, category in COLLECTION_CATEGORIES.items():
        if collection_name in name:
            return category
    return "UNKNOWN"


def infer_state(fields: dict[str, Any], text: str = "") -> str:
    values = " ".join(
        str(value) for key, value in fields.items()
        if key.casefold() in {"status", "result", "state", "record_status"}
    )
    combined = normalized(values + " " + text)
    if (
        re.search(r"\b(?:result|status|state)[\"']?\s*[:=]\s*[\"']?(?:not_found|not found|absent|deleted|removed|disabled|blocked|revoked)\b", combined)
        or re.search(r"\|\s*(?:not_found|not found|absent|deleted|removed)\s*\|", combined)
        or re.search(r"\brows[=: ]+0\b", combined)
        or re.search(r"\bhttp_status[=: ]+404\b", combined)
        or re.search(r"\bstatus_code[=: ]+404\b", combined)
        or str(fields.get("rows", "")) == "0"
        or str(fields.get("http_status", "")) == "404"
        or str(fields.get("status_code", "")) == "404"
    ):
        return "ABSENT"
    if (
        re.search(r"\b(active|enabled|healthy|allowed|true|present|found|ready|available)\b", combined)
        or re.search(r"\brows[=: ]+1\b", combined)
        or str(fields.get("rows", "")) == "1"
        or str(fields.get("http_status", "")) == "200"
    ):
        return "PRESENT"
    return ""


def extract_record(
    file_id: str,
    captured_at: str,
    observed_at: str,
    system: Any,
    category_value: Any,
    fields: dict[str, Any],
) -> EvidenceRecord | None:
    resource = fields.get("resource_id") or fields.get("id")
    if not resource:
        return None
    category = category_from(category_value, fields.get("record_type", ""))
    if category == "UNKNOWN":
        category = category_from(str(category_value) + " " + " ".join(fields), "")
    text = json.dumps(fields, ensure_ascii=False, sort_keys=True, default=str)
    return EvidenceRecord(
        file_id=file_id,
        captured_at=captured_at,
        observed_at=observed_at or captured_at,
        system_id=canonical_system(system, category),
        category=category,
        resource_id=str(resource),
        fields=fields,
        text=text,
        state_hint=infer_state(fields),
    )


def parse_json_evidence(file_id: str, captured_at: str, value: Any) -> list[EvidenceRecord]:
    records: list[EvidenceRecord] = []
    if not isinstance(value, dict):
        return records
    snapshots = value.get("snapshots")
    if isinstance(snapshots, list):
        for snapshot in snapshots:
            if not isinstance(snapshot, dict):
                continue
            observed = str(snapshot.get("captured_at") or captured_at)
            system = snapshot.get("data_store") or snapshot.get("system")
            collection = snapshot.get("collection") or snapshot.get("record_type")
            snapshot_records = snapshot.get("records", [])
            if category_from(collection) == "USER_PROFILE" and not snapshot_records:
                records.append(EvidenceRecord(
                    file_id=file_id,
                    captured_at=captured_at,
                    observed_at=observed,
                    system_id=canonical_system(system, "USER_PROFILE"),
                    category="USER_PROFILE",
                    resource_id="__inventory__",
                    fields={},
                    text="",
                    state_hint="ABSENT",
                ))
            for item in snapshot_records:
                if isinstance(item, dict):
                    record = extract_record(file_id, captured_at, observed, system, collection, item)
                    if record:
                        records.append(record)
    for item in value.get("records", []) if isinstance(value.get("records"), list) else []:
        if not isinstance(item, dict):
            continue
        observed = str(item.get("recorded_at") or item.get("event_time") or captured_at)
        record = extract_record(
            file_id, captured_at, observed,
            item.get("system") or item.get("source_system") or value.get("system") or value.get("source"),
            item.get("record_type") or item.get("collection") or item.get("data_category") or value.get("collection"),
            item,
        )
        if record:
            records.append(record)
    service_exports = value.get("service_exports")
    if isinstance(service_exports, list):
        for service_export in service_exports:
            if not isinstance(service_export, dict):
                continue
            system = service_export.get("service") or service_export.get("system")
            collection = service_export.get("collection") or service_export.get("data_category")
            for item in service_export.get("records", []):
                if isinstance(item, dict):
                    record = extract_record(
                        file_id,
                        captured_at,
                        str(item.get("captured_at") or item.get("recorded_at") or captured_at),
                        system,
                        collection or item.get("record_type"),
                        item,
                    )
                    if record:
                        records.append(record)
    elif isinstance(service_exports, dict):
        collection_categories = {
            ("account_service", "profile_lookups"): "USER_PROFILE",
            ("analytics_platform", "profiles"): "ANALYTICS_PROFILE",
            ("backup_service", "restore_entries"): "BACKUP_ARCHIVE",
            ("export_service", "exports"): "USER_EXPORT",
            ("integration_service", "connectors"): "ACTIVE_DATA_FLOW",
            ("search_service", "index_queries"): "SEARCH_INDEX_ENTRY",
            ("security_service", "audit_records"): "SECURITY_AUDIT_LOG",
            ("support_platform", "tickets"): "SUPPORT_MESSAGE",
        }
        for system, collections in service_exports.items():
            if not isinstance(collections, dict):
                continue
            for collection, items in collections.items():
                if not isinstance(items, list):
                    continue
                category = collection_categories.get((system, collection), collection)
                for item in items:
                    if not isinstance(item, dict):
                        continue
                    fields = dict(item)
                    nested = fields.pop("profile", None)
                    if isinstance(nested, dict):
                        fields.update(nested)
                    record = extract_record(
                        file_id,
                        captured_at,
                        str(item.get("observed_at") or item.get("captured_at") or captured_at),
                        system,
                        category,
                        fields,
                    )
                    if record:
                        records.append(record)
    return records


def parse_sql_evidence(file_id: str, captured_at: str, path: Path) -> list[EvidenceRecord]:
    records: list[EvidenceRecord] = []
    connection = sqlite3.connect(":memory:")
    try:
        connection.executescript(path.read_text(encoding="utf-8-sig"))
        tables = connection.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name"
        ).fetchall()
        for (table,) in tables:
            columns = [row[1] for row in connection.execute(f'PRAGMA table_info("{table}")')]
            table_category = category_from(table)
            if table_category == "USER_PROFILE":
                records.append(EvidenceRecord(
                    file_id=file_id,
                    captured_at=captured_at,
                    observed_at=captured_at,
                    system_id=SYSTEMS["USER_PROFILE"],
                    category="USER_PROFILE",
                    resource_id="__inventory__",
                    fields={},
                    text="",
                    state_hint="ABSENT",
                ))
            for values in connection.execute(f'SELECT * FROM "{table}"'):
                row = dict(zip(columns, values))
                raw = row.get("record_json")
                fields = json.loads(raw) if isinstance(raw, str) else row
                if not isinstance(fields, dict):
                    continue
                system = row.get("origin_system") or table
                category = row.get("collection_name") or table
                record = extract_record(
                    file_id, captured_at,
                    str(row.get("updated_at") or captured_at),
                    system, category, fields,
                )
                if record:
                    records.append(record)
    finally:
        connection.close()
    return records


RESOURCE_PATTERN = re.compile(
    r"\b(?:account|search|analytics|support|export|backup|audit_record|"
    r"tombstone|marketing|cache|data_flow|telemetry|attachment|"
    r"email_delivery|secondary_identifier)_\d+\b",
    re.IGNORECASE,
)
TIME_PATTERN = re.compile(r"\b20\d{2}-\d\d-\d\d[T ]\d\d:\d\d:\d\d(?:\.\d+)?Z?\b")
KEY_VALUE_PATTERN = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*)=([\"'][^\"']*[\"']|[^ \t,;]+)")


def parse_text_evidence(
    file_id: str,
    captured_at: str,
    text: str,
    document_context: bool = False,
) -> list[EvidenceRecord]:
    records: list[EvidenceRecord] = []
    lines = text.splitlines()
    trace_context: dict[str, list[str]] = defaultdict(list)
    for line in lines:
        trace = dict(KEY_VALUE_PATTERN.findall(line)).get("trace_id")
        if trace:
            trace_context[trace.strip("\"'")].append(line)
    for line in lines:
        resources = list(dict.fromkeys(RESOURCE_PATTERN.findall(line)))
        if not resources:
            continue
        pairs: dict[str, Any] = {}
        for key, value in KEY_VALUE_PATTERN.findall(line):
            pairs[key.casefold()] = value.strip("\"'")
        observed_match = TIME_PATTERN.search(line)
        observed = observed_match.group(0).replace(" ", "T") if observed_match else captured_at
        normalized_line = normalized(line)
        category = category_from(
            line,
            " ".join(
                name for name in COLLECTION_CATEGORIES
                if name.replace("_", " ") in normalized_line
            ),
        )
        if category == "UNKNOWN":
            if "tombstone" in normalized_line:
                category = "ACCOUNT_TOMBSTONE"
            elif "backup" in normalized_line or "restore" in normalized_line:
                category = "BACKUP_ARCHIVE"
            elif "data_flow" in normalized_line or "connector" in normalized_line:
                category = "ACTIVE_DATA_FLOW"
            elif "search" in normalized_line or "index" in normalized_line:
                category = "SEARCH_INDEX_ENTRY"
            elif "analytics" in normalized_line:
                category = "ANALYTICS_PROFILE"
            elif "support" in normalized_line or "attachment" in normalized_line:
                category = "SUPPORT_ATTACHMENT" if "attachment" in normalized_line else "SUPPORT_MESSAGE"
            elif "export" in normalized_line:
                category = "USER_EXPORT"
            elif "audit_record" in normalized_line or "security" in normalized_line:
                category = "SECURITY_AUDIT_LOG"
            elif "account" in normalized_line:
                category = "USER_PROFILE"
        for resource in resources:
            fields = dict(pairs)
            fields["resource_id"] = resource
            fields["evidence_text"] = line
            trace = pairs.get("trace_id", "").strip("\"'")
            related_lines = trace_context.get(trace, []) if trace else []
            related_text = "\n".join(related_lines)
            if related_text:
                fields["evidence_text"] = related_text
            record = EvidenceRecord(
                file_id=file_id,
                captured_at=captured_at,
                observed_at=observed,
                system_id=canonical_system(pairs.get("system") or pairs.get("service"), category),
                category=category,
                resource_id=resource,
                fields=fields,
                text=fields["evidence_text"],
                state_hint=infer_state(fields, fields["evidence_text"]),
            )
            records.append(record)
    if document_context:
        normalized_text = normalized(text)
        category = "UNKNOWN"
        if "support" in normalized_text or "attachment" in normalized_text:
            category = "SUPPORT_ATTACHMENT" if "attachment" in normalized_text else "SUPPORT_MESSAGE"
        elif "security" in normalized_text and "audit_record" in normalized_text:
            category = "SECURITY_AUDIT_LOG"
        for resource in dict.fromkeys(RESOURCE_PATTERN.findall(text)):
            records.append(EvidenceRecord(
                file_id=file_id,
                captured_at=captured_at,
                observed_at=captured_at,
                system_id=canonical_system("", category),
                category=category,
                resource_id=resource,
                fields={"resource_id": resource},
                text=text,
                state_hint=infer_state({}, text),
            ))
    return records


def load_evidence() -> tuple[list[EvidenceRecord], list[dict[str, str]], list[str]]:
    manifest = read_csv(DATASET / "evidence_files.csv")
    records: list[EvidenceRecord] = []
    limitations: list[str] = []
    for row in manifest:
        relative = Path(row["file_path"])
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f"Evidence path escapes dataset directory: {row['file_path']}")
        path = DATASET / relative
        suffix = path.suffix.casefold()
        file_id = row["file_id"]
        captured = row["captured_at"]
        if not at_or_before(captured, "9999-12-31T23:59:59Z"):
            raise ValueError(f"Invalid evidence timestamp for {file_id}: {captured}")
        if suffix == ".json":
            data = json.loads(path.read_text(encoding="utf-8-sig"))
            records.extend(parse_json_evidence(file_id, captured, data))
        elif suffix == ".sql":
            records.extend(parse_sql_evidence(file_id, captured, path))
        elif suffix in {".txt", ".log"}:
            records.extend(parse_text_evidence(file_id, captured, path.read_text(encoding="utf-8-sig", errors="replace")))
        elif suffix == ".pdf":
            try:
                import pymupdf
            except ImportError:
                try:
                    import fitz as pymupdf
                except ImportError:
                    limitations.append(f"{file_id}: PDF text not extracted (PyMuPDF is not installed)")
                    continue
            document = pymupdf.open(path)
            pdf_text = "\n".join(page.get_text() for page in document)
            records.extend(parse_text_evidence(file_id, captured, pdf_text, document_context=True))
        elif suffix == ".png":
            try:
                from PIL import Image
            except ImportError:
                limitations.append(f"{file_id}: image not inspected (Pillow is not installed)")
                continue
            with Image.open(path) as image:
                image.verify()
            limitations.append(f"{file_id}: screenshot dimensions verified; OCR unavailable")
        else:
            limitations.append(f"{file_id}: unsupported evidence extension {suffix or '(none)'}")
    return records, manifest, limitations


def aliases_for(
    request: dict[str, str],
    identities: list[dict[str, str]],
    audit_rows: list[dict[str, str]],
) -> tuple[str | None, set[str]]:
    requested_email = normalized(request["email"]).strip()
    cutoff = request["audit_at"]
    possible_ids: set[str] = set()
    aliases = {requested_email}
    for person in identities:
        fields = [person.get("email", "")]
        if normalized(person.get("email", "")) == requested_email:
            possible_ids.add(person["user_id"])
        if person["user_id"] in possible_ids and at_or_before(person.get("updated_at", ""), cutoff):
            fields.extend([person.get("name", ""), person.get("phone", ""), person.get("email_hash", "")])
            aliases.update(normalized(value).strip() for value in fields if value)
    for audit in audit_rows:
        if not at_or_before(audit.get("event_time", ""), cutoff):
            continue
        field_name = audit.get("field_name", "").casefold()
        if audit["user_id"] in possible_ids or normalized(audit.get("old_value", "")) == requested_email or normalized(audit.get("new_value", "")) == requested_email:
            possible_ids.add(audit["user_id"])
            aliases.update(
                normalized(value).strip()
                for value in (audit.get("old_value", ""), audit.get("new_value", ""))
                if value
            )
    if len(possible_ids) == 1:
        user_id = next(iter(possible_ids))
        for person in identities:
            if person["user_id"] == user_id and at_or_before(person.get("updated_at", ""), cutoff):
                aliases.update(
                    normalized(person.get(field, "")).strip()
                    for field in ("name", "email", "phone", "email_hash")
                    if person.get(field)
                )
        for audit in audit_rows:
            if audit["user_id"] == user_id and at_or_before(audit.get("event_time", ""), cutoff):
                aliases.update(
                    normalized(audit.get(field, "")).strip()
                    for field in ("old_value", "new_value")
                    if audit.get(field)
                )
    else:
        user_id = None
    aliases.update(hashlib.sha256(alias.encode("utf-8")).hexdigest() for alias in tuple(aliases) if "@" in alias)
    return user_id, {alias for alias in aliases if len(alias) >= 3}


NON_DELETION = re.compile(
    r"\b(do not|don't|dont|never|without|not asking for|not requesting|"
    r"no request for|keep my account|retain my account)\b.{0,50}\b"
    r"(delete|deletion|erase|erasure|remove|removal|purge|close|closure)\b"
)
DELETION = re.compile(
    r"\b(delet(?:e|ed|ing|ion)|eras(?:e|ed|ing|ure)|remov(?:e|ed|ing|al)|"
    r"purge|close|closed|closing|"
    r"closure|cancel|cancellation|forget|forgotten|suppress|suppression|"
    r"supprimer|effacer|suppression|supression|eliminar|eliminacion|borrar|borrado|"
    r"cancellare|eliminare|rimuovere|loeschen|löschen|entfernen|"
    r"apagar|excluir|deletar|apague|消去|削除|삭제|탈퇴)\b"
)


def authorizes_deletion(text: str) -> bool:
    value = normalized(text)
    if NON_DELETION.search(value):
        return False
    return bool(
        DELETION.search(value)
        or any(term in text for term in ("削除", "消去", "删除", "销毁", "탈퇴", "삭제"))
        or re.search(r"\b(?:account|profile|personal data|identifiable data)\b.{0,50}\b(?:gone|removed|no longer exists)\b", value)
    )


def matches_subject(record: EvidenceRecord, user_id: str | None, aliases: set[str]) -> bool:
    fields = {key.casefold(): value for key, value in record.fields.items()}
    references = {
        normalized(str(value)).strip()
        for key, value in fields.items()
        if value is not None and key in {
            "user_id", "customer_reference", "subject_reference", "owner_email",
            "email", "phone", "full_name", "name", "email_hash", "selector",
            "subject_selector", "subject_ref", "user_ref", "subject_id",
            "customer_ref", "account", "customer_id",
        }
    }
    if user_id and normalized(user_id) in references:
        return True
    if user_id and re.search(
        rf"(?<![a-z0-9_]){re.escape(normalized(user_id))}(?![a-z0-9_])",
        normalized(record.text),
    ):
        return True
    if any(reference in aliases for reference in references):
        return True
    haystack = normalized(record.text)
    return any(
        alias and len(alias) >= 6 and ("@" in alias or re.fullmatch(r"[0-9a-f]{64}", alias))
        and re.search(rf"(?<![a-z0-9]){re.escape(alias)}(?![a-z0-9])", haystack)
        for alias in aliases
    )


def policy_action(category: str, fields: dict[str, Any], rules: dict[str, list[dict[str, str]]]) -> str:
    candidates = rules.get(category, [])
    if not candidates:
        return ""
    normalized_fields = {
        key.casefold(): normalized(str(value))
        for key, value in fields.items()
        if value not in (None, "", "null")
    }
    if (
        category == "ANALYTICS_PROFILE"
        and normalized_fields.get("event") == "contact_lookup_completed"
    ):
        return "DELETE"
    if category == "SUPPORT_MESSAGE":
        content = " ".join(normalized_fields.values())
        if "contact_query" in content and not any(
            key in normalized_fields
            for key in ("message_text", "message_excerpt", "conversation_text", "body")
        ):
            return "DELETE"
    return candidates[0]["required_action"]


def identifiers_exposed(record: EvidenceRecord, aliases: set[str]) -> bool:
    fields = {key.casefold(): value for key, value in record.fields.items()}
    direct = {"email", "phone", "name", "full_name", "email_hash", "owner_email", "subject_reference", "subject_selector"}
    for key, value in fields.items():
        if key in direct and value not in (None, "", "null"):
            normalized_value = normalized(str(value)).strip()
            if normalized_value in aliases or key in {"email", "phone", "name", "full_name", "owner_email"}:
                return True
        elif value not in (None, "", "null"):
            normalized_value = normalized(str(value)).strip()
            if normalized_value in aliases and (
                "@" in normalized_value
                or re.fullmatch(r"[0-9a-f]{64}", normalized_value)
            ):
                return True
    haystack = normalized(record.text)
    return any(alias in haystack for alias in aliases if alias and "@" in alias)


def is_active(record: EvidenceRecord) -> bool:
    fields = {key.casefold(): value for key, value in record.fields.items()}
    if record.category == "ACTIVE_DATA_FLOW":
        active_value = fields.get("enabled", fields.get("active", fields.get("status", "")))
        if active_value in (None, ""):
            return record.state_hint == "PRESENT" or bool(
                re.search(r"\b(active|enabled|healthy|continuous)\b", normalized(record.text))
            )
        return str(active_value).casefold() in {
            "true", "1", "yes", "enabled", "active", "healthy",
        }
    if record.category == "BACKUP_ARCHIVE":
        restore_allowed = fields.get(
            "restore_allowed",
            fields.get("restore_access", fields.get("restore_permitted", "")),
        )
        if str(restore_allowed).casefold() in {"true", "1", "yes", "allowed", "enabled", "active"}:
            return True
        eligible = str(fields.get("eligible", "")).casefold() in {"true", "1", "yes"}
        deletion_block = str(fields.get("deletion_block", "")).casefold() in {"true", "1", "yes"}
        if eligible and not deletion_block:
            return True
        return bool(
            re.search(r"\|\s*active\s*\|", normalized(record.text))
            or re.search(r"\brestore[_ ](?:access|status|state)[=: ]+active\b", normalized(record.text))
        )
    return False


def classify(record: EvidenceRecord, aliases: set[str], rules: dict[str, list[dict[str, str]]]) -> tuple[str, str] | None:
    category = record.category
    fields = {key.casefold(): value for key, value in record.fields.items()}
    state = record.state_hint
    if category == "ACTIVE_DATA_FLOW":
        if is_active(record):
            return "REPORT_ACTIVE_DATA_FLOW", "ACTIVE"
        return None
    if category == "BACKUP_ARCHIVE":
        if is_active(record):
            return "REPORT_RESTORE_RISK", "ACTIVE"
        return None
    action = policy_action(category, record.fields, rules)
    if action == "DELETE":
        if state == "ABSENT":
            return None
        return "REPORT_REMAINING_RECORD", "PRESENT"
    if action == "REDACT":
        if state == "ABSENT" and category != "ACCOUNT_TOMBSTONE":
            return None
        if category == "ACCOUNT_TOMBSTONE":
            identifiers = [
                key for key in ("full_name", "name", "email", "phone", "email_hash")
                if fields.get(key) not in (None, "", "null")
            ]
            if not identifiers:
                return None
        elif not identifiers_exposed(record, aliases):
            return None
        return "REPORT_EXPOSED_PII", "PRESENT"
    if action == "ANONYMIZE":
        if (state == "ABSENT" and category != "ACCOUNT_TOMBSTONE") or not identifiers_exposed(record, aliases):
            return None
        return "REPORT_EXPOSED_PII", "PRESENT"
    if action == "RETAIN":
        return None
    return None


def verification_for(record: EvidenceRecord, action: str) -> tuple[str, str] | None:
    if record.category == "BACKUP_ARCHIVE":
        if not is_active(record):
            return "VERIFY_RESTORE_BLOCKED", "BLOCKED"
        return None
    if record.category == "ACTIVE_DATA_FLOW":
        if not is_active(record):
            return "VERIFY_DATA_FLOW_DISABLED", "DISABLED"
        return None
    if action == "DELETE" and record.state_hint == "ABSENT":
        return "VERIFY_RECORD_ABSENT", "ABSENT"
    if action == "REDACT" and not identifiers_exposed(record, set()):
        return "VERIFY_RECORD_REDACTED", "REDACTED"
    if action == "ANONYMIZE" and not identifiers_exposed(record, set()):
        return "VERIFY_RECORD_ANONYMIZED", "ANONYMIZED"
    if action == "RETAIN" and record.state_hint != "ABSENT":
        return "VERIFY_RECORD_PRESENT", "PRESENT"
    return None


def build_case_steps(
    request: dict[str, str],
    evidence: list[EvidenceRecord],
    identities: list[dict[str, str]],
    audit_rows: list[dict[str, str]],
    rules: dict[str, list[dict[str, str]]],
    activity_rows: list[dict[str, str]] | None = None,
) -> tuple[str, list[dict[str, Any]]]:
    if not authorizes_deletion(request["request_text"]):
        return "NOT_APPLICABLE", []
    user_id, aliases = aliases_for(request, identities, audit_rows)
    cutoff = request["audit_at"]
    requested_at = parse_time(request.get("requested_at", ""))
    account_resource = linked_account_resource(request, activity_rows or [])
    eligible = [
        record for record in evidence
        if at_or_before(record.observed_at, cutoff)
        and not (
            record.category == "USER_PROFILE"
            and record.state_hint == "ABSENT"
            and requested_at is not None
            and (parse_time(record.observed_at) or requested_at) < requested_at
        )
    ]
    direct_matches = [
        record for record in eligible if matches_subject(record, user_id, aliases)
    ]
    correlated_ids: set[str] = set()
    if activity_rows:
        correlated_ids = correlate_activity_resources(
            request, activity_rows, cutoff, user_id, aliases
        )
    directly_linked_profiles = [
        record for record in eligible
        if record.category == "USER_PROFILE"
        and record.resource_id != "__inventory__"
        and matches_subject(record, user_id, aliases)
    ]
    if directly_linked_profiles:
        account_resource = max(
            directly_linked_profiles,
            key=lambda record: (record.observed_at, record.captured_at, record.file_id),
        ).resource_id
    elif correlated_ids:
        account_candidates = {
            record.resource_id for record in eligible
            if record.category == "USER_PROFILE"
            and record.resource_id in correlated_ids
            and record.resource_id != "__inventory__"
        }
        if len(account_candidates) == 1:
            account_resource = next(iter(account_candidates))
    matched_resource_keys = {
        (record.file_id, record.resource_id, record.category, record.system_id)
        for record in eligible
        if matches_subject(record, user_id, aliases)
        or record.resource_id in correlated_ids
        or (
            account_resource is not None
            and record.category == "USER_PROFILE"
            and record.resource_id == account_resource
        )
    }
    relevant = [
        record for record in eligible
        if (record.file_id, record.resource_id, record.category, record.system_id)
        in matched_resource_keys
    ]
    relevant = merge_related_observations(relevant)

    # Keep the strongest/latest observation for each resource and category.
    latest: dict[tuple[str, str, str], EvidenceRecord] = {}
    for record in relevant:
        key = (record.system_id, record.resource_id, record.category)
        prior = latest.get(key)
        if prior is None or (record.observed_at, record.captured_at, record.file_id) > (
            prior.observed_at, prior.captured_at, prior.file_id
        ):
            latest[key] = record

    findings: list[dict[str, Any]] = []
    future_actions: dict[tuple[str, str, str], tuple[str, str]] = {}
    evidence_verifications: list[dict[str, Any]] = []
    for record in latest.values():
        classified = classify(record, aliases, rules)
        action = policy_action(record.category, record.fields, rules)
        if classified:
            operation, state = classified
            findings.append({
                "system_id": record.system_id,
                "resource_id": record.resource_id,
                "operation": operation,
                "state": state,
                "evidence_id": record.file_id,
            })
            remediation = {
                "DELETE": ("DELETE_RECORD", "ABSENT"),
                "REDACT": ("REDACT_RECORD", "REDACTED"),
                "ANONYMIZE": ("ANONYMIZE_RECORD", "ANONYMIZED"),
            }.get(action)
            if operation == "REPORT_ACTIVE_DATA_FLOW":
                remediation = ("DISABLE_DATA_FLOW", "DISABLED")
            elif operation == "REPORT_RESTORE_RISK":
                remediation = ("BLOCK_RESTORE", "BLOCKED")
            if remediation:
                future_actions[(record.system_id, record.resource_id, record.category)] = remediation
        else:
            verification = verification_for(record, action)
            if verification:
                operation, state = verification
                evidence_verifications.append({
                    "system_id": record.system_id,
                    "resource_id": record.resource_id,
                    "operation": operation,
                    "state": state,
                    "evidence_id": record.file_id,
                })

    account_record = next(
        (
            record for record in latest.values()
            if record.category == "USER_PROFILE"
            and record.resource_id == account_resource
        ),
        None,
    )
    if account_resource and account_record is None:
        absence_file = latest_complete_profile_snapshot(evidence, cutoff)
        if absence_file:
            evidence_verifications.append({
                "system_id": "account_service",
                "resource_id": account_resource,
                "operation": "VERIFY_RECORD_ABSENT",
                "state": "ABSENT",
                "evidence_id": absence_file,
            })
    elif account_resource and account_record is not None:
        if not any(
            item["resource_id"] == account_resource
            and item["operation"] == "REPORT_REMAINING_RECORD"
            for item in findings
        ):
            classified = classify(account_record, aliases, rules)
            if classified:
                operation, state = classified
                findings.append({
                    "system_id": "account_service",
                    "resource_id": account_resource,
                    "operation": operation,
                    "state": state,
                    "evidence_id": account_record.file_id,
                })
                future_actions[("account_service", account_resource, "USER_PROFILE")] = (
                    "DELETE_RECORD", "ABSENT"
                )

    if findings:
        steps = sorted(findings, key=step_sort_key)
        remediation_steps = [
            {
                "system_id": system,
                "resource_id": resource,
                "operation": operation,
                "state": state,
                "evidence_id": "",
            }
            for (system, resource, _), (operation, state) in future_actions.items()
        ]
        steps.extend(sorted(remediation_steps, key=step_sort_key))
        verify_by_resource: dict[tuple[str, str, str], dict[str, Any]] = {}
        for item in evidence_verifications:
            item = {**item, "evidence_id": ""}
            verify_by_resource[(item["system_id"], item["resource_id"], item["operation"])] = item
        for (system, resource, category), (operation, state) in future_actions.items():
            verify_operation = {
                "DELETE_RECORD": "VERIFY_RECORD_ABSENT",
                "REDACT_RECORD": "VERIFY_RECORD_REDACTED",
                "ANONYMIZE_RECORD": "VERIFY_RECORD_ANONYMIZED",
                "DISABLE_DATA_FLOW": "VERIFY_DATA_FLOW_DISABLED",
                "BLOCK_RESTORE": "VERIFY_RESTORE_BLOCKED",
            }[operation]
            verify_by_resource[(system, resource, verify_operation)] = {
                "system_id": system,
                "resource_id": resource,
                "operation": verify_operation,
                "state": state,
                "evidence_id": "",
            }
        if account_resource and not any(
            key[1] == account_resource and key[2] == "VERIFY_RECORD_ABSENT"
            for key in verify_by_resource
        ):
            verify_by_resource[("account_service", account_resource, "VERIFY_RECORD_ABSENT")] = {
                "system_id": "account_service",
                "resource_id": account_resource,
                "operation": "VERIFY_RECORD_ABSENT",
                "state": "ABSENT",
                "evidence_id": "",
            }
        steps.extend(sorted(verify_by_resource.values(), key=step_sort_key))
        return "INCOMPLETE", number_steps(steps)
    if evidence_verifications:
        return "COMPLETE", number_steps(sorted(evidence_verifications, key=step_sort_key))
    # Lack of observable proof is not treated as proof of successful deletion.
    return "INCOMPLETE", []


def linked_account_resource(
    request: dict[str, str],
    activity_rows: list[dict[str, str]],
) -> str | None:
    """Use a nearby deletion event to identify the target, not to prove its state."""
    requested = parse_time(request.get("requested_at", ""))
    reported = parse_time(request.get("reported_at", ""))
    cutoff = parse_time(request.get("audit_at", ""))
    if not requested or not reported or not cutoff:
        return None
    candidates: list[tuple[float, str]] = []
    for activity in activity_rows:
        if (
            activity.get("event_type") != "DELETE_RECORD"
            or activity.get("target_system") != "account_service"
        ):
            continue
        occurred = parse_time(activity.get("event_time", ""))
        if not occurred or occurred > cutoff:
            continue
        if occurred < requested.replace(hour=0, minute=0, second=0, microsecond=0):
            continue
        distance = abs((occurred - reported).total_seconds())
        if distance <= 30 * 60:
            candidates.append((distance, activity["resource_id"]))
    candidates.sort()
    if not candidates or (len(candidates) > 1 and candidates[0][0] == candidates[1][0]):
        return None
    return candidates[0][1]


def latest_complete_profile_snapshot(evidence: list[EvidenceRecord], cutoff: str) -> str:
    snapshots = {
        (record.observed_at, record.file_id)
        for record in evidence
        if record.category == "USER_PROFILE"
        and record.resource_id == "__inventory__"
        and at_or_before(record.observed_at, cutoff)
    }
    return max(snapshots, default=("", ""))[1]


def correlate_activity_resources(
    request: dict[str, str],
    activity_rows: list[dict[str, str]],
    cutoff: str,
    user_id: str | None = None,
    aliases: set[str] | None = None,
) -> set[str]:
    """Link activity resources only when the event itself names this subject."""
    requested = parse_time(request.get("requested_at", ""))
    if not requested or not user_id:
        return set()
    tokens = {
        normalized(value).strip()
        for value in aliases or set()
        if "@" in value or re.fullmatch(r"[0-9a-f]{64}", value)
    }
    tokens.add(normalized(user_id))
    return_set: set[str] = set()
    for activity in activity_rows:
        event_time = parse_time(activity.get("event_time", ""))
        if (
            not event_time
            or event_time < requested
            or not at_or_before(activity.get("event_time", ""), cutoff)
        ):
            continue
        details = normalized(activity.get("details", ""))
        if any(
            re.search(rf"(?<![a-z0-9_]){re.escape(token)}(?![a-z0-9_])", details)
            for token in tokens
        ):
            return_set.add(activity["resource_id"])
    return return_set


def merge_related_observations(records: list[EvidenceRecord]) -> list[EvidenceRecord]:
    grouped: dict[tuple[str, str, str, str], list[EvidenceRecord]] = defaultdict(list)
    for record in records:
        grouped[(record.file_id, record.resource_id, record.category, record.system_id)].append(record)
    merged = []
    for (file_id, resource_id, category, system_id), entries in grouped.items():
        fields: dict[str, Any] = {}
        for entry in sorted(entries, key=lambda item: item.observed_at):
            fields.update(entry.fields)
        text = "\n".join(entry.text for entry in entries)
        latest_entry = max(entries, key=lambda item: item.observed_at)
        merged.append(EvidenceRecord(
            file_id=file_id,
            captured_at=latest_entry.captured_at,
            observed_at=latest_entry.observed_at,
            system_id=system_id,
            category=category,
            resource_id=resource_id,
            fields=fields,
            text=text,
            state_hint=infer_state(fields, text),
        ))
    return merged


def step_sort_key(step: dict[str, Any]) -> tuple[int, int, str, str]:
    return (
        PHASE_ORDER.get(step.get("phase", ""), PHASE_ORDER.get(operation_phase(step["operation"]), 9)),
        OP_ORDER.get(step["operation"], 99),
        step["system_id"],
        step["resource_id"],
    )


def operation_phase(operation: str) -> str:
    for phase, operations in OPERATIONS.items():
        if operation in operations:
            return phase
    return ""


def number_steps(steps: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for index, step in enumerate(steps, 1):
        result.append({
            "step_no": index,
            "phase": operation_phase(step["operation"]),
            "system_id": step["system_id"],
            "resource_id": step["resource_id"],
            "operation": step["operation"],
            "state": step["state"],
            "evidence_id": step["evidence_id"],
        })
    return result


def load_rules() -> dict[str, list[dict[str, str]]]:
    result: dict[str, list[dict[str, str]]] = defaultdict(list)
    for rule in read_csv(DATASET / "deletion_rules.csv"):
        result[rule["data_category"]].append(rule)
    return result


def generate_output(output_path: Path = OUTPUT) -> dict[str, Any]:
    requests = read_csv(DATASET / "deletion_requests.csv")
    identities = read_csv(DATASET / "user_identities.csv")
    audit_rows = read_csv(DATASET / "user_audit_log.csv")
    # Activity is loaded as context only; its reported results are not state proof.
    activity_rows = read_csv(DATASET / "system_activity.csv")
    evidence, manifest, limitations = load_evidence()
    rules = load_rules()
    result_rows = []
    for request in requests:
        status, steps = build_case_steps(
            request, evidence, identities, audit_rows, rules, activity_rows
        )
        result_rows.append({
            "case_id": request["case_id"],
            "deletion_status": status,
            "steps_json": json.dumps(steps, ensure_ascii=False, separators=(",", ":")),
        })
    result_rows.sort(key=lambda row: row["case_id"])
    with output_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["case_id", "deletion_status", "steps_json"], lineterminator="\n")
        writer.writeheader()
        writer.writerows(result_rows)
    return {
        "requests": len(requests),
        "activities_loaded": len(activity_rows),
        "evidence_files": len(manifest),
        "evidence_records": len(evidence),
        "limitations": limitations,
        "statuses": {
            status: sum(row["deletion_status"] == status for row in result_rows)
            for status in ("COMPLETE", "INCOMPLETE", "NOT_APPLICABLE")
        },
        "output": str(output_path),
    }


if __name__ == "__main__":
    try:
        summary = generate_output()
    except (OSError, csv.Error, json.JSONDecodeError, sqlite3.Error, ValueError) as error:
        print(f"Audit failed: {error}", file=sys.stderr)
        raise SystemExit(1) from error
    print(json.dumps(summary, ensure_ascii=False, indent=2))