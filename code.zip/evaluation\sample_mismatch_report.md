# Per-case public sample mismatch report

Generated from `sample_deletion_requests.csv`, `sample_output.csv`, and the current deterministic solution.
No expected output is read by the production solution.

## Mismatch summary

- Status mismatches: 1.
- Cases with step-order-only differences: 0.
- Most common missing steps (phase/operation/system, occurrence count):
  - `VERIFICATION/VERIFY_RECORD_ABSENT/account_service`: 14
  - `VERIFICATION/VERIFY_RECORD_ANONYMIZED/analytics_platform`: 7
  - `VERIFICATION/VERIFY_RECORD_PRESENT/security_service`: 3
- Most common extra steps (phase/operation/system, occurrence count):
  - `VERIFICATION/VERIFY_RECORD_ABSENT/account_service`: 2
- Status mismatches:
  - `case_04`: `COMPLETE` expected, `INCOMPLETE` predicted

## case_03

- Status: expected `COMPLETE`, predicted `COMPLETE`.
- Step counts: expected 3, predicted 2.
- Missing steps: 1; extra steps: 0.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ANONYMIZED` `analytics_platform/analytics_9406` state=`ANONYMIZED` evidence=`evidence_94`

## case_04

- Status: expected `COMPLETE`, predicted `INCOMPLETE`.
- Step counts: expected 2, predicted 0.
- Missing steps: 2; extra steps: 0.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_004` state=`ABSENT` evidence=`evidence_54`
  - `VERIFICATION/VERIFY_RECORD_ANONYMIZED` `analytics_platform/analytics_901` state=`ANONYMIZED` evidence=`evidence_56`

## case_09

- Status: expected `INCOMPLETE`, predicted `INCOMPLETE`.
- Step counts: expected 5, predicted 3.
- Missing steps: 2; extra steps: 0.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_3960` state=`ABSENT` evidence=``
  - `VERIFICATION/VERIFY_RECORD_PRESENT` `security_service/audit_record_4902` state=`PRESENT` evidence=``
- Aligned step field differences:
  - Field mismatch for VERIFY_RESTORE_BLOCKED backup_service/backup_4978: step_no expected=5 actual=3

## case_18

- Status: expected `INCOMPLETE`, predicted `INCOMPLETE`.
- Step counts: expected 14, predicted 13.
- Missing steps: 2; extra steps: 1.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_5521` state=`ABSENT` evidence=``
  - `VERIFICATION/VERIFY_RECORD_PRESENT` `security_service/audit_record_6645` state=`PRESENT` evidence=``
- Extra predicted steps:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_5193` state=`ABSENT` evidence=``
- Aligned step field differences:
  - Field mismatch for VERIFY_RECORD_REDACTED support_platform/support_5569: step_no expected=12 actual=11
  - Field mismatch for VERIFY_RECORD_ANONYMIZED analytics_platform/analytics_037: step_no expected=13 actual=12
  - Field mismatch for VERIFY_DATA_FLOW_DISABLED integration_service/data_flow_4890: step_no expected=14 actual=13

## case_20

- Status: expected `INCOMPLETE`, predicted `INCOMPLETE`.
- Step counts: expected 8, predicted 7.
- Missing steps: 2; extra steps: 1.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_5037` state=`ABSENT` evidence=``
  - `VERIFICATION/VERIFY_RECORD_PRESENT` `security_service/audit_record_5569` state=`PRESENT` evidence=``
- Extra predicted steps:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_5193` state=`ABSENT` evidence=``
- Aligned step field differences:
  - Field mismatch for VERIFY_DATA_FLOW_DISABLED integration_service/data_flow_1770: step_no expected=8 actual=7

## case_21

- Status: expected `COMPLETE`, predicted `COMPLETE`.
- Step counts: expected 3, predicted 1.
- Missing steps: 2; extra steps: 0.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_6440` state=`ABSENT` evidence=`evidence_92`
  - `VERIFICATION/VERIFY_RECORD_ANONYMIZED` `analytics_platform/analytics_5335` state=`ANONYMIZED` evidence=`evidence_92`
- Aligned step field differences:
  - Field mismatch for VERIFY_RECORD_PRESENT security_service/audit_record_3737: step_no expected=2 actual=1, evidence_id expected='evidence_92' actual='evidence_02'

## case_22

- Status: expected `INCOMPLETE`, predicted `INCOMPLETE`.
- Step counts: expected 8, predicted 7.
- Missing steps: 1; extra steps: 0.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_4990` state=`ABSENT` evidence=``
- Aligned step field differences:
  - Field mismatch for VERIFY_RECORD_ABSENT search_service/search_8911: step_no expected=6 actual=5
  - Field mismatch for VERIFY_RECORD_PRESENT security_service/audit_record_3482: step_no expected=7 actual=6
  - Field mismatch for VERIFY_RECORD_ANONYMIZED analytics_platform/analytics_4440: step_no expected=8 actual=7

## case_23

- Status: expected `INCOMPLETE`, predicted `INCOMPLETE`.
- Step counts: expected 8, predicted 7.
- Missing steps: 1; extra steps: 0.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_410` state=`ABSENT` evidence=``
- Aligned step field differences:
  - Field mismatch for REPORT_REMAINING_RECORD export_service/export_7364: evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for REPORT_REMAINING_RECORD search_service/search_898: evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for VERIFY_RECORD_ABSENT export_service/export_7364: step_no expected=6 actual=5
  - Field mismatch for VERIFY_RECORD_ABSENT search_service/search_898: step_no expected=7 actual=6
  - Field mismatch for VERIFY_RECORD_PRESENT security_service/audit_record_4128: step_no expected=8 actual=7

## case_24

- Status: expected `INCOMPLETE`, predicted `INCOMPLETE`.
- Step counts: expected 7, predicted 7.
- Missing steps: 0; extra steps: 0.
- Aligned step field differences:
  - Field mismatch for REPORT_REMAINING_RECORD account_service/account_5334: evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for REPORT_REMAINING_RECORD search_service/search_5577: evidence_id expected='evidence_92' actual='evidence_02'

## case_25

- Status: expected `COMPLETE`, predicted `COMPLETE`.
- Step counts: expected 3, predicted 1.
- Missing steps: 2; extra steps: 0.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_3136` state=`ABSENT` evidence=`evidence_92`
  - `VERIFICATION/VERIFY_RECORD_ANONYMIZED` `analytics_platform/analytics_1895` state=`ANONYMIZED` evidence=`evidence_92`
- Aligned step field differences:
  - Field mismatch for VERIFY_RECORD_PRESENT security_service/audit_record_451: step_no expected=2 actual=1, evidence_id expected='evidence_92' actual='evidence_02'

## case_26

- Status: expected `COMPLETE`, predicted `COMPLETE`.
- Step counts: expected 6, predicted 5.
- Missing steps: 1; extra steps: 0.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ANONYMIZED` `analytics_platform/analytics_4566` state=`ANONYMIZED` evidence=`evidence_92`
- Aligned step field differences:
  - Field mismatch for VERIFY_RECORD_PRESENT security_service/audit_record_5416: evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for VERIFY_RECORD_REDACTED support_platform/support_4715: evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for VERIFY_DATA_FLOW_DISABLED integration_service/data_flow_6244: step_no expected=5 actual=4, evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for VERIFY_RESTORE_BLOCKED backup_service/backup_3120: step_no expected=6 actual=5, evidence_id expected='evidence_92' actual='evidence_02'

## case_27

- Status: expected `COMPLETE`, predicted `COMPLETE`.
- Step counts: expected 6, predicted 4.
- Missing steps: 2; extra steps: 0.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_3866` state=`ABSENT` evidence=`evidence_92`
  - `VERIFICATION/VERIFY_RECORD_ANONYMIZED` `analytics_platform/analytics_4574` state=`ANONYMIZED` evidence=`evidence_92`
- Aligned step field differences:
  - Field mismatch for VERIFY_RECORD_PRESENT security_service/audit_record_3830: step_no expected=2 actual=1, evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for VERIFY_RECORD_REDACTED support_platform/support_4707: step_no expected=3 actual=2, evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for VERIFY_DATA_FLOW_DISABLED integration_service/data_flow_2295: step_no expected=5 actual=3, evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for VERIFY_RESTORE_BLOCKED backup_service/backup_5970: step_no expected=6 actual=4, evidence_id expected='evidence_92' actual='evidence_02'

## case_28

- Status: expected `COMPLETE`, predicted `COMPLETE`.
- Step counts: expected 6, predicted 4.
- Missing steps: 2; extra steps: 0.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_5482` state=`ABSENT` evidence=`evidence_92`
  - `VERIFICATION/VERIFY_RECORD_ANONYMIZED` `analytics_platform/analytics_6077` state=`ANONYMIZED` evidence=`evidence_92`
- Aligned step field differences:
  - Field mismatch for VERIFY_RECORD_PRESENT security_service/audit_record_9265: step_no expected=2 actual=1, evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for VERIFY_RECORD_REDACTED support_platform/support_2351: step_no expected=3 actual=2, evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for VERIFY_DATA_FLOW_DISABLED integration_service/data_flow_2337: step_no expected=5 actual=3, evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for VERIFY_RESTORE_BLOCKED backup_service/backup_838: step_no expected=6 actual=4, evidence_id expected='evidence_92' actual='evidence_02'

## case_29

- Status: expected `INCOMPLETE`, predicted `INCOMPLETE`.
- Step counts: expected 14, predicted 13.
- Missing steps: 1; extra steps: 0.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_7012` state=`ABSENT` evidence=``
- Aligned step field differences:
  - Field mismatch for REPORT_REMAINING_RECORD search_service/search_1993: evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for REPORT_EXPOSED_PII analytics_platform/analytics_5208: evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for REPORT_EXPOSED_PII support_platform/support_5281: evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for REPORT_ACTIVE_DATA_FLOW integration_service/data_flow_3827: evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for VERIFY_RECORD_ABSENT search_service/search_1993: step_no expected=10 actual=9
  - Field mismatch for VERIFY_RECORD_PRESENT security_service/audit_record_3954: step_no expected=11 actual=10
  - Field mismatch for VERIFY_RECORD_REDACTED support_platform/support_5281: step_no expected=12 actual=11
  - Field mismatch for VERIFY_RECORD_ANONYMIZED analytics_platform/analytics_5208: step_no expected=13 actual=12
  - Field mismatch for VERIFY_DATA_FLOW_DISABLED integration_service/data_flow_3827: step_no expected=14 actual=13

## case_30

- Status: expected `INCOMPLETE`, predicted `INCOMPLETE`.
- Step counts: expected 14, predicted 13.
- Missing steps: 1; extra steps: 0.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_4163` state=`ABSENT` evidence=``
- Aligned step field differences:
  - Field mismatch for REPORT_REMAINING_RECORD search_service/search_9359: evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for REPORT_EXPOSED_PII analytics_platform/analytics_3697: evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for REPORT_EXPOSED_PII support_platform/support_6477: evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for REPORT_ACTIVE_DATA_FLOW integration_service/data_flow_8524: evidence_id expected='evidence_92' actual='evidence_02'
  - Field mismatch for VERIFY_RECORD_ABSENT search_service/search_9359: step_no expected=10 actual=9
  - Field mismatch for VERIFY_RECORD_PRESENT security_service/audit_record_1707: step_no expected=11 actual=10
  - Field mismatch for VERIFY_RECORD_REDACTED support_platform/support_6477: step_no expected=12 actual=11
  - Field mismatch for VERIFY_RECORD_ANONYMIZED analytics_platform/analytics_3697: step_no expected=13 actual=12
  - Field mismatch for VERIFY_DATA_FLOW_DISABLED integration_service/data_flow_8524: step_no expected=14 actual=13

## case_31

- Status: expected `COMPLETE`, predicted `COMPLETE`.
- Step counts: expected 3, predicted 2.
- Missing steps: 1; extra steps: 0.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_4857` state=`ABSENT` evidence=`evidence_51`
- Aligned step field differences:
  - Field mismatch for VERIFY_RECORD_PRESENT security_service/audit_record_6909: step_no expected=2 actual=1
  - Field mismatch for VERIFY_RECORD_REDACTED identity_service/tombstone_440: step_no expected=3 actual=2

## case_32

- Status: expected `INCOMPLETE`, predicted `INCOMPLETE`.
- Step counts: expected 5, predicted 4.
- Missing steps: 1; extra steps: 0.
- Expected steps missing from prediction:
  - `VERIFICATION/VERIFY_RECORD_ABSENT` `account_service/account_8858` state=`ABSENT` evidence=``
- Aligned step field differences:
  - Field mismatch for VERIFY_RECORD_PRESENT security_service/audit_record_7068: step_no expected=4 actual=3
  - Field mismatch for VERIFY_RECORD_REDACTED identity_service/tombstone_9178: step_no expected=5 actual=4

