# Evaluation Report

## Public sample results

The evaluation script runs the same `build_case_steps` implementation against
all 32 rows in `dataset/sample_deletion_requests.csv`, then compares its output
to the participant-facing `dataset/sample_output.csv`. It does not load or
hardcode organizer-only answers.

| Metric | Result |
| --- | ---: |
| Sample cases | 32 |
| Case/status accuracy | 31/32 (96.9%) |
| Exact output-row accuracy (status and complete steps array) | 15/32 (46.9%) |
| Exact sequence accuracy (phase, operation, system, resource, full ordered array) | 16/32 (50.0%) |
| Expected-step field accuracy (positional, seven documented fields) | 1,031/1,351 (76.3%) |

Compared with the previous iteration's 14/32 exact rows, 14/32 exact
sequences, and 1,015/1,351 field matches, this iteration gained one exact row,
two exact sequences, and 16 expected-step field matches. Status accuracy
remained 31/32.

Expected-step field accuracy compares each reference step field with the
prediction at the same array position; missing fields count as incorrect.
Extra predicted fields are not included in that denominator. Exact row and
sequence metrics require the complete ordered arrays to match.

The metrics and aligned per-case missing/extra/field report are reproducible with:

```powershell
py -3 code\evaluation\evaluate_sample.py
```

The evaluator writes `code/evaluation/sample_mismatch_report.md`; it lists
missing and extra steps (including phase, operation, system, and resource),
aligned field differences such as `step_no` and `evidence_id`, ordering
differences, and status mismatches.

## Additional independent tests

Seventeen custom `unittest` cases are in `code/evaluation/test_main.py`:

1. Positive deletion intent, negated deletion intent, and Japanese deletion text.
2. Inclusive audit cutoff and the participant activity timestamp format.
3. Parsing an empty profile lookup with an HTTP 404 state.
4. Detection of direct identifiers in a retained account tombstone.
5. Active backup restore eligibility when no deletion block is present.
6. Hashed email correlation keys remain attributable to the known subject.
7. Phase, operation, and resource ordering.
8. Stable user-ID matching in unstructured audit-log text.
9. Activity resource linking requires the event details to identify the subject.
10. Support treatment distinguishes a contact-index lookup from retained conversation content.
11. Known categories map database/replica names to canonical service IDs.
12. A restore-blocked backup verifies as `VERIFY_RESTORE_BLOCKED`.
13. Future verification steps have empty evidence citations.
14. A pre-request absence lookup cannot establish the later audit-time state.
15. A point-in-time observation remains eligible when its evidence bundle was collected later.
16. An observation after `audit_at` is excluded even if the evidence file was collected earlier.
17. An analytics contact lookup follows the delete policy rather than profile anonymization.

All seventeen tests passed in the final focused test run.

```powershell
py -3 -m unittest discover -s code\evaluation -p "test_*.py" -v
```

## Failures found and improvements made

- Initial sample runs exposed false resource associations caused by joining
  nearby global activity events. Activity-only resource associations were
  removed; activity operation results are not treated as proof of data state.
- Nested dictionary-form service exports and search SQL table names were not
  initially recognized. The parser now handles those layouts and records
  explicit empty-profile lookup results.
- Policy actions now use the supplied category rules, with a specific
  distinction for contact-index query records versus support conversations.
- Backup eligibility and deletion-block fields are interpreted as restore-risk
  evidence, and a blocked backup is verified as blocked rather than merely
  present.
- Hashed aliases in correlation fields were not initially recognized as
  identifying. These are now checked against known identity hashes.
- Stable internal user IDs in unstructured logs are matched with token
  boundaries, and replica/store labels normalize to canonical system IDs.
- Audit eligibility now uses each record's observed point-in-time timestamp;
  it no longer rejects a historical snapshot solely because the containing
  evidence bundle was collected later. Observations after `audit_at` remain
  excluded. Added regression coverage for both sides of this cutoff.
- Analytics `contact_lookup_completed` events are distinguished from
  attributable analytics profiles and use the deletion action; a regression
  test protects that policy distinction.
- A negative account lookup predating the deletion request cannot establish
  the later state. Proposed future verification steps use empty evidence
  references.
- Timestamp parsing now accepts the observed colon-separated year/date form
  in addition to ISO-8601 timestamps.

The most frequent remaining mismatches are missing account-absence steps
(14), missing anonymous analytics verification associations (7), and missing
retained security-audit verification associations (3). Two account-absence
steps are still extra because available activity timing alone does not prove
which request owns a resource. Anonymous records with all subject identifiers
removed cannot always be safely associated with a request; the solution does
not infer identity from resource-number patterns or trust a workflow result
as state proof. Screenshot evidence is validated as image files but is not
OCR-parsed, and unsupported or unavailable parsers are surfaced in the run
summary.

The one remaining status mismatch is `case_04`: the sample reference expects
`COMPLETE`, but the implementation returns `INCOMPLETE` because the account
resource association cannot be substantiated from participant-visible evidence.
It deliberately does not invent that association.
