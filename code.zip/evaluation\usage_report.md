# Usage Report

## Final full-dataset run

The program is deterministic and does not call a model provider or model API.
For the full-dataset run, the measured application-level usage is:

| Measure | Result |
| --- | ---: |
| Model providers used | None |
| Models used | None |
| Model API calls | 0 |
| Input tokens | 0 |
| Output tokens | 0 |
| Total tokens | 0 |
| Average tokens per request (518 requests) | 0 |
| Estimated total model cost | $0.00 |
| Estimated model cost per request | $0.00 |

These figures describe inference performed by `code/main.py`; they do not
estimate development-assistant usage, for which this environment exposes no
verifiable per-turn token or cost data. No model identifier is inferred.
