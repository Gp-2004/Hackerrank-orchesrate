import sys
import unittest
from pathlib import Path


CODE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CODE))

import main


class AuditSolutionTests(unittest.TestCase):
    def test_deletion_intent_and_negation(self):
        self.assertTrue(main.authorizes_deletion("Please erase my account and data."))
        self.assertFalse(main.authorizes_deletion("Do not delete my account."))
        self.assertTrue(main.authorizes_deletion("アカウントを削除してください"))

    def test_cutoff_parsing_and_activity_timestamp(self):
        self.assertTrue(main.at_or_before(
            "2026:08-27T07:44:03Z",
            "2026-08-27T08:00:00Z",
        ))
        self.assertFalse(main.at_or_before(
            "2026-08-27T08:00:01Z",
            "2026-08-27T08:00:00Z",
        ))

    def test_service_export_parser_retains_empty_profile_lookup(self):
        parsed = main.parse_json_evidence(
            "evidence_test",
            "2026-09-15T12:00:00Z",
            {
                "service_exports": {
                    "account_service": {
                        "profile_lookups": [{
                            "observed_at": "2026-09-15T11:00:00Z",
                            "profile": None,
                            "resource_id": "account_123",
                            "status_code": 404,
                        }]
                    }
                }
            },
        )
        self.assertEqual(len(parsed), 1)
        self.assertEqual(parsed[0].category, "USER_PROFILE")
        self.assertEqual(parsed[0].state_hint, "ABSENT")
        self.assertEqual(parsed[0].resource_id, "account_123")

    def test_tombstone_with_direct_identifiers_requires_redaction(self):
        record = main.EvidenceRecord(
            file_id="evidence_test",
            captured_at="2026-09-15T12:00:00Z",
            observed_at="2026-09-15T12:00:00Z",
            system_id="identity_service",
            category="ACCOUNT_TOMBSTONE",
            resource_id="tombstone_123",
            fields={
                "subject_reference": "user_123",
                "email": "person@example.test",
                "account_status": "DELETED",
            },
            text='{"email":"person@example.test"}',
        )
        rules = {"ACCOUNT_TOMBSTONE": [{"required_action": "REDACT"}]}
        self.assertEqual(
            main.classify(record, {"person@example.test"}, rules),
            ("REPORT_EXPOSED_PII", "PRESENT"),
        )

    def test_restore_candidate_without_a_deletion_block_is_active_risk(self):
        record = main.EvidenceRecord(
            file_id="evidence_test",
            captured_at="2026-09-15T12:00:00Z",
            observed_at="2026-09-15T12:00:00Z",
            system_id="backup_service",
            category="BACKUP_ARCHIVE",
            resource_id="backup_123",
            fields={"eligible": "true", "deletion_block": "false"},
            text="",
        )
        self.assertEqual(
            main.classify(record, set(), {}),
            ("REPORT_RESTORE_RISK", "ACTIVE"),
        )

    def test_hashed_alias_in_correlation_key_remains_attributable(self):
        hashed_email = "a" * 64
        record = main.EvidenceRecord(
            file_id="evidence_test",
            captured_at="2026-09-15T12:00:00Z",
            observed_at="2026-09-15T12:00:00Z",
            system_id="analytics_platform",
            category="ANALYTICS_PROFILE",
            resource_id="analytics_123",
            fields={"correlation_key": hashed_email},
            text="",
        )
        self.assertTrue(main.identifiers_exposed(record, {hashed_email}))

    def test_log_text_can_link_a_retained_record_by_stable_user_id(self):
        record = main.EvidenceRecord(
            file_id="evidence_test",
            captured_at="2026-09-15T12:00:00Z",
            observed_at="2026-09-15T12:00:00Z",
            system_id="security_service",
            category="SECURITY_AUDIT_LOG",
            resource_id="audit_record_123",
            fields={"resource_id": "audit_record_123"},
            text="audit_record_123 FOUND user_32",
        )
        self.assertTrue(main.matches_subject(record, "user_32", set()))
        self.assertFalse(main.matches_subject(record, "user_3", set()))

    def test_activity_resource_link_requires_subject_in_details(self):
        request = {
            "requested_at": "2026-09-01T00:00:00Z",
            "audit_at": "2026-09-15T00:00:00Z",
        }
        events = [
            {
                "event_time": "2026-09-02T00:00:00Z",
                "resource_id": "analytics_123",
                "details": "operation for user_123",
            },
            {
                "event_time": "2026-09-02T00:01:00Z",
                "resource_id": "analytics_456",
                "details": "operation for user_124",
            },
        ]
        self.assertEqual(
            main.correlate_activity_resources(
                request, events, request["audit_at"], "user_123", set()
            ),
            {"analytics_123"},
        )

    def test_category_policy_respects_rule_and_contact_query_semantics(self):
        rules = {"SUPPORT_MESSAGE": [{"required_action": "REDACT"}]}
        self.assertEqual(
            main.policy_action(
                "SUPPORT_MESSAGE",
                {
                    "event": "deletion_marker_check",
                    "evidence_text": "contact_query_completed rows=1",
                    "rows": 1,
                },
                rules,
            ),
            "DELETE",
        )
        self.assertEqual(
            main.policy_action(
                "SUPPORT_MESSAGE",
                {"message_excerpt": "customer asked about an order"},
                rules,
            ),
            "REDACT",
        )

    def test_analytics_contact_lookup_uses_contact_deletion_policy(self):
        rules = {"ANALYTICS_PROFILE": [{"required_action": "ANONYMIZE"}]}
        self.assertEqual(
            main.policy_action(
                "ANALYTICS_PROFILE",
                {
                    "event": "contact_lookup_completed",
                    "email_opt_in": "true",
                    "rows": "1",
                },
                rules,
            ),
            "DELETE",
        )

    def test_known_categories_use_canonical_system_names(self):
        self.assertEqual(
            main.canonical_system("support_replica", "SUPPORT_MESSAGE"),
            "support_platform",
        )
        self.assertEqual(
            main.category_from("backup_restore_entries"),
            "BACKUP_ARCHIVE",
        )

    def test_blocked_backup_verification_is_not_record_present(self):
        record = main.EvidenceRecord(
            file_id="evidence_test",
            captured_at="2026-09-15T12:00:00Z",
            observed_at="2026-09-15T12:00:00Z",
            system_id="backup_service",
            category="BACKUP_ARCHIVE",
            resource_id="backup_123",
            fields={"restore_allowed": False},
            text="",
        )
        self.assertEqual(
            main.verification_for(record, "RETAIN"),
            ("VERIFY_RESTORE_BLOCKED", "BLOCKED"),
        )

    def test_future_verifications_have_no_evidence_citation(self):
        request = {
            "email": "user@example.test",
            "requested_at": "2026-09-01T00:00:00Z",
            "audit_at": "2026-09-15T12:00:00Z",
            "request_text": "Please delete my account.",
        }
        record = main.EvidenceRecord(
            file_id="evidence_test",
            captured_at="2026-09-02T00:00:00Z",
            observed_at="2026-09-02T00:00:00Z",
            system_id="search_service",
            category="SEARCH_INDEX_ENTRY",
            resource_id="search_123",
            fields={"email": "user@example.test"},
            text='{"email":"user@example.test"}',
            state_hint="PRESENT",
        )
        status, steps = main.build_case_steps(
            request,
            [record],
            [],
            [],
            {"SEARCH_INDEX_ENTRY": [{"required_action": "DELETE"}]},
        )
        self.assertEqual(status, "INCOMPLETE")
        self.assertEqual(
            [step["evidence_id"] for step in steps if step["phase"] == "VERIFICATION"],
            [""],
        )

    def test_pre_request_absence_lookup_does_not_prove_audit_time_absence(self):
        request = {
            "email": "user@example.test",
            "requested_at": "2026-09-01T00:00:00Z",
            "audit_at": "2026-09-15T12:00:00Z",
            "request_text": "Please delete my account.",
        }
        record = main.EvidenceRecord(
            file_id="evidence_test",
            captured_at="2026-08-31T00:00:00Z",
            observed_at="2026-08-31T00:00:00Z",
            system_id="account_service",
            category="USER_PROFILE",
            resource_id="account_123",
            fields={"email": "user@example.test"},
            text='{"email":"user@example.test"}',
            state_hint="ABSENT",
        )
        status, steps = main.build_case_steps(
            request,
            [record],
            [],
            [],
            {"USER_PROFILE": [{"required_action": "DELETE"}]},
        )
        self.assertEqual(status, "INCOMPLETE")
        self.assertEqual(steps, [])

    def test_late_collected_snapshot_uses_its_observation_time_for_cutoff(self):
        request = {
            "email": "user@example.test",
            "requested_at": "2026-09-01T00:00:00Z",
            "audit_at": "2026-09-15T12:00:00Z",
            "request_text": "Please delete my account.",
        }
        record = main.EvidenceRecord(
            file_id="evidence_test",
            captured_at="2026-09-17T12:00:00Z",
            observed_at="2026-09-15T09:00:00Z",
            system_id="account_service",
            category="USER_PROFILE",
            resource_id="account_123",
            fields={"email": "user@example.test"},
            text='{"email":"user@example.test"}',
            state_hint="PRESENT",
        )
        status, steps = main.build_case_steps(
            request,
            [record],
            [],
            [],
            {"USER_PROFILE": [{"required_action": "DELETE"}]},
        )
        self.assertEqual(status, "INCOMPLETE")
        self.assertEqual(
            [(step["operation"], step["evidence_id"]) for step in steps],
            [
                ("REPORT_REMAINING_RECORD", "evidence_test"),
                ("DELETE_RECORD", ""),
                ("VERIFY_RECORD_ABSENT", ""),
            ],
        )

    def test_observation_after_audit_cutoff_is_not_eligible(self):
        request = {
            "email": "user@example.test",
            "requested_at": "2026-09-01T00:00:00Z",
            "audit_at": "2026-09-15T12:00:00Z",
            "request_text": "Please delete my account.",
        }
        record = main.EvidenceRecord(
            file_id="evidence_test",
            captured_at="2026-09-15T11:00:00Z",
            observed_at="2026-09-15T13:00:00Z",
            system_id="account_service",
            category="USER_PROFILE",
            resource_id="account_123",
            fields={"email": "user@example.test"},
            text='{"email":"user@example.test"}',
            state_hint="PRESENT",
        )
        status, steps = main.build_case_steps(
            request,
            [record],
            [],
            [],
            {"USER_PROFILE": [{"required_action": "DELETE"}]},
        )
        self.assertEqual(status, "INCOMPLETE")
        self.assertEqual(steps, [])

    def test_steps_sort_by_phase_then_operation_and_resource(self):
        steps = [
            {"operation": "VERIFY_RECORD_ABSENT", "system_id": "a", "resource_id": "x"},
            {"operation": "DELETE_RECORD", "system_id": "z", "resource_id": "x"},
            {"operation": "REPORT_REMAINING_RECORD", "system_id": "b", "resource_id": "y"},
        ]
        self.assertEqual(
            [step["operation"] for step in sorted(steps, key=main.step_sort_key)],
            ["REPORT_REMAINING_RECORD", "DELETE_RECORD", "VERIFY_RECORD_ABSENT"],
        )


if __name__ == "__main__":
    unittest.main()
