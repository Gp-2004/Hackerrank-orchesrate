"""Compare the generated sample predictions with the public reference output."""

import csv
import difflib
import json
from collections import Counter
from pathlib import Path

import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "code"))

import main as audit_main


def read_rows(path: Path) -> dict[str, dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return {row["case_id"]: row for row in csv.DictReader(stream)}


def main() -> None:
    expected = read_rows(ROOT / "dataset" / "sample_output.csv")
    requests = audit_main.read_csv(ROOT / "dataset" / "sample_deletion_requests.csv")
    identities = audit_main.read_csv(ROOT / "dataset" / "user_identities.csv")
    audit_rows = audit_main.read_csv(ROOT / "dataset" / "user_audit_log.csv")
    activity_rows = audit_main.read_csv(ROOT / "dataset" / "system_activity.csv")
    evidence, _, _ = audit_main.load_evidence()
    rules = audit_main.load_rules()
    actual = {}
    for request in requests:
        status, steps = audit_main.build_case_steps(
            request, evidence, identities, audit_rows, rules, activity_rows
        )
        actual[request["case_id"]] = {
            "deletion_status": status,
            "steps": steps,
        }
    fields = (
        "step_no",
        "phase",
        "system_id",
        "resource_id",
        "operation",
        "state",
        "evidence_id",
    )
    status_correct = 0
    exact_rows = 0
    sequence_correct = 0
    correct_fields = 0
    expected_fields = 0
    missing_by_operation: Counter[str] = Counter()
    extra_by_operation: Counter[str] = Counter()
    order_only_cases = 0
    status_mismatches: list[str] = []
    mismatch_lines = [
        "# Per-case public sample mismatch report",
        "",
        "Generated from `sample_deletion_requests.csv`, `sample_output.csv`, and the current deterministic solution.",
        "No expected output is read by the production solution.",
        "",
    ]
    for case_id, reference in expected.items():
        prediction = actual.get(case_id)
        if prediction is None:
            continue
        expected_steps = json.loads(reference["steps_json"])
        predicted_steps = prediction["steps"]
        status_matches = prediction["deletion_status"] == reference["deletion_status"]
        status_correct += status_matches
        if not status_matches:
            status_mismatches.append(
                f"`{case_id}`: `{reference['deletion_status']}` expected, "
                f"`{prediction['deletion_status']}` predicted"
            )
        exact_rows += (
            prediction["deletion_status"] == reference["deletion_status"]
            and predicted_steps == expected_steps
        )
        sequence_correct += [
            (step["phase"], step["operation"], step["system_id"], step["resource_id"])
            for step in predicted_steps
        ] == [
            (step["phase"], step["operation"], step["system_id"], step["resource_id"])
            for step in expected_steps
        ]
        for index, expected_step in enumerate(expected_steps):
            for field in fields:
                expected_fields += 1
                if (
                    index < len(predicted_steps)
                    and predicted_steps[index].get(field) == expected_step[field]
                ):
                    correct_fields += 1
        if (
            prediction["deletion_status"] != reference["deletion_status"]
            or predicted_steps != expected_steps
        ):
            expected_keys = [
                (step["phase"], step["operation"], step["system_id"], step["resource_id"])
                for step in expected_steps
            ]
            predicted_keys = [
                (step["phase"], step["operation"], step["system_id"], step["resource_id"])
                for step in predicted_steps
            ]
            matcher = difflib.SequenceMatcher(
                a=expected_keys, b=predicted_keys, autojunk=False
            )
            missing: list[dict[str, object]] = []
            extra: list[dict[str, object]] = []
            aligned: list[tuple[dict[str, object], dict[str, object]]] = []
            for tag, i1, i2, j1, j2 in matcher.get_opcodes():
                if tag in {"delete", "replace"}:
                    missing.extend(expected_steps[i1:i2])
                    missing_by_operation.update(
                        f"{step['phase']}/{step['operation']}/{step['system_id']}"
                        for step in expected_steps[i1:i2]
                    )
                if tag in {"insert", "replace"}:
                    extra.extend(predicted_steps[j1:j2])
                    extra_by_operation.update(
                        f"{step['phase']}/{step['operation']}/{step['system_id']}"
                        for step in predicted_steps[j1:j2]
                    )
                if tag == "equal":
                    aligned.extend(zip(expected_steps[i1:i2], predicted_steps[j1:j2]))
            differences: list[str] = []
            for expected_step, predicted_step in aligned:
                changed = [
                    field for field in fields
                    if expected_step.get(field) != predicted_step.get(field)
                ]
                if changed:
                    differences.append(
                        f"  - Field mismatch for {expected_step['operation']} "
                        f"{expected_step['system_id']}/{expected_step['resource_id']}: "
                        + ", ".join(
                            f"{field} expected={expected_step.get(field)!r} "
                            f"actual={predicted_step.get(field)!r}"
                            for field in changed
                        )
                    )
            mismatch_lines.extend([
                f"## {case_id}",
                "",
                f"- Status: expected `{reference['deletion_status']}`, "
                f"predicted `{prediction['deletion_status']}`.",
                f"- Step counts: expected {len(expected_steps)}, predicted {len(predicted_steps)}.",
                f"- Missing steps: {len(missing)}; extra steps: {len(extra)}.",
            ])
            if missing:
                mismatch_lines.append("- Expected steps missing from prediction:")
                mismatch_lines.extend(
                    f"  - `{step['phase']}/{step['operation']}` "
                    f"`{step['system_id']}/{step['resource_id']}` "
                    f"state=`{step['state']}` evidence=`{step['evidence_id']}`"
                    for step in missing
                )
            if extra:
                mismatch_lines.append("- Extra predicted steps:")
                mismatch_lines.extend(
                    f"  - `{step['phase']}/{step['operation']}` "
                    f"`{step['system_id']}/{step['resource_id']}` "
                    f"state=`{step['state']}` evidence=`{step['evidence_id']}`"
                    for step in extra
                )
            if differences:
                mismatch_lines.append("- Aligned step field differences:")
                mismatch_lines.extend(differences)
            if expected_keys != predicted_keys and not missing and not extra:
                mismatch_lines.append("- Sequence differs in ordering.")
            if (
                expected_keys != predicted_keys
                and sorted(expected_keys) == sorted(predicted_keys)
            ):
                order_only_cases += 1
                phases_expected = [step[0] for step in expected_keys]
                phases_actual = [step[0] for step in predicted_keys]
                operations_expected = [step[1] for step in expected_keys]
                operations_actual = [step[1] for step in predicted_keys]
                mismatch_lines.append(
                    "- Ordering detail: "
                    f"phase order {'matches' if phases_expected == phases_actual else 'differs'}; "
                    f"operation/resource sequence "
                    f"{'matches' if operations_expected == operations_actual else 'differs'}."
                )
            mismatch_lines.append("")
    total = len(expected)
    summary_lines = [
        "## Mismatch summary",
        "",
        f"- Status mismatches: {len(status_mismatches)}.",
        f"- Cases with step-order-only differences: {order_only_cases}.",
        "- Most common missing steps (phase/operation/system, occurrence count):",
    ]
    summary_lines.extend(
        f"  - `{key}`: {count}"
        for key, count in missing_by_operation.most_common(10)
    )
    summary_lines.append("- Most common extra steps (phase/operation/system, occurrence count):")
    summary_lines.extend(
        f"  - `{key}`: {count}"
        for key, count in extra_by_operation.most_common(10)
    )
    summary_lines.append("- Status mismatches:")
    summary_lines.extend(f"  - {line}" for line in status_mismatches)
    summary_lines.append("")
    mismatch_lines[5:5] = summary_lines
    print(f"Sample cases: {total}")
    print(f"Status / case accuracy: {status_correct}/{total} ({status_correct / total:.1%})")
    print(f"Exact row accuracy: {exact_rows}/{total} ({exact_rows / total:.1%})")
    print(f"Exact sequence accuracy: {sequence_correct}/{total} ({sequence_correct / total:.1%})")
    print(
        f"Expected-step field accuracy: {correct_fields}/{expected_fields} "
        f"({correct_fields / expected_fields:.1%})"
    )
    report_path = ROOT / "code" / "evaluation" / "sample_mismatch_report.md"
    report_path.write_text("\n".join(mismatch_lines) + "\n", encoding="utf-8")
    print(f"Per-case mismatch report: {report_path}")


if __name__ == "__main__":
    main()
